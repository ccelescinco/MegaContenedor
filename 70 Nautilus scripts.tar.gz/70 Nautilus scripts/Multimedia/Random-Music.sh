#!/bin/bash
gnome-terminal -e ~/.gnome2/nautilus-scripts/Multimedia/.random-Music.sh
